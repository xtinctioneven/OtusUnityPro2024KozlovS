namespace Atomic.Objects
{
    public interface IMutableAtomicObject : IAtomicObject, IMutableAtomicEntity, IMutalbleAtomicBehaviour 
    {
    }
}